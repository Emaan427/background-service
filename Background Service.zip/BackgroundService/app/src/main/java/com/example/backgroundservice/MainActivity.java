package com.example.backgroundservice;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;

import com.example.backgroundservice.R;

public class MainActivity extends AppCompatActivity {

    Button startBtn, stopBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startBtn = findViewById(R.id.startBtn);
        stopBtn = findViewById(R.id.stopBtn);

        startBtn.setOnClickListener(this::onClick);

        stopBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, com.example.backgroundservice.MyBackgroundService.class);
            stopService(intent);
        });
    }

    private void onClick(View v) {
        Intent intent = new Intent(this, com.example.backgroundservice.MyBackgroundService.class);
        startService(intent);
    }
}
